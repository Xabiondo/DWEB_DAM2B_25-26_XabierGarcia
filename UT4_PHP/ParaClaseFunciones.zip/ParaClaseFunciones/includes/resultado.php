<?php
      include "includes/cabecera.php";
      
      echo "<div class='resultado' />";
      
      echo $resultado;
      echo "</div>";
      
      include "includes/pie.php";
?>
